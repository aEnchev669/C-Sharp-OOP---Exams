﻿using NavalVessels.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace NavalVessels.Models
{
    public class Battleship : Vessel, IBattleship
    {
        private const double Initial_Armor_Thickness = 300;
        public Battleship(string name, double mainWeaponCaliber, double speed, double armorThickness) : base(name, mainWeaponCaliber, speed, armorThickness)
        {
        }

        public bool SonarMode { get; private set; }

        public override void RepairVessel()
        {
            
                ArmorThickness = Initial_Armor_Thickness;
            
        }

        public void ToggleSonarMode()
        {
            if (SonarMode == false)
            {
                MainWeaponCaliber += 40;
                Speed -= 5;
                SonarMode = true;
            }
            else
            {
                MainWeaponCaliber -= 40;
                Speed += 5;
                SonarMode = false;
            }
        }

        public override string ToString()
        {
            string onOff = SonarMode == true ? "On" : "Off";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString())
               .AppendLine($" *Sonar mode: {onOff}");

            return sb.ToString().TrimEnd(); 
        }
    }
}
