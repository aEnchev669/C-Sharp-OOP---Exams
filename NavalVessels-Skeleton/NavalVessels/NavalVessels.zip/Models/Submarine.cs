﻿using NavalVessels.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace NavalVessels.Models
{
    public class Submarine : Vessel, ISubmarine
    {
        private const double Initial_Armor_Thickness = 200;
        public Submarine(string name, double mainWeaponCaliber, double speed, double armorThickness) : base(name, mainWeaponCaliber, speed, armorThickness)
        {
        }

        public bool SubmergeMode { get; private set; }

        public override void RepairVessel()
        {
            if (ArmorThickness < 200)
            {
                ArmorThickness = Initial_Armor_Thickness;
            }
        }

        public void ToggleSubmergeMode()
        {
            if (SubmergeMode == false)
            {
                MainWeaponCaliber += 40;
                Speed -= 4;
                SubmergeMode = true;
            }
            else
            {
                MainWeaponCaliber -= 40;
                Speed += 4;
                SubmergeMode = false;
            }
        }

        public override string ToString()
        {

            string onOff = SubmergeMode == true ? "On" : "Off";

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString())
               .AppendLine($" *Submerge mode: {onOff}");

            return sb.ToString();
        }
    }
}
