﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarRacing.Models.Racers
{
    internal class ProfessionalRacer
    {
    }
}
