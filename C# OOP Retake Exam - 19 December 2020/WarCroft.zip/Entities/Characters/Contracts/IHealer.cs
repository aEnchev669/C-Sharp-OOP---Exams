﻿namespace WarCroft.Entities.Characters.Contracts
{
	public interface IHealer
	{
		void Heal(IAttacker character);
	}
}